<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Total Stok</title>
    <style>
        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            font-size: 10px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 18px;
        }
        .header p {
            margin: 5px 0;
            font-size: 12px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .text-center {
            text-align: center;
        }
        .footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 9px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Laporan Total Stok Barang</h1>
        <p>Tanggal Cetak: <?php echo e($tanggalCetak); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Serial Number</th>
                <th>Merek & Model</th>
                <th>Kategori</th>
                <th>Lokasi</th>
                <th>Rak</th>
                <th>Status</th>
                <th>Kondisi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $barangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td><?php echo e($barang->serial_number ?: '-'); ?></td>
                    <td><?php echo e($barang->merek_model ?: '-'); ?></td>
                    <td><?php echo e($barang->kategori ?: '-'); ?></td>
                    <td><?php echo e($barang->lokasi ?: '-'); ?></td>
                    <td><?php echo e($barang->nama_rak ? "{$barang->nama_rak} ({$barang->kode_rak}-{$barang->baris})" : '-'); ?></td>
                    <td><?php echo e($barang->status_awal ?: '-'); ?></td>
                    <td><?php echo e($barang->kondisi ?: '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">Tidak ada data yang ditemukan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        Dicetak oleh Sistem Manajemen Inventaris
    </div>
</body>
</html>
<?php /**PATH D:\laragon\www\inventaris-bintang\resources\views\reports\stock_total_pdf.blade.php ENDPATH**/ ?>