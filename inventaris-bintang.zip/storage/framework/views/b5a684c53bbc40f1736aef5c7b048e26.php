<!DOCTYPE html>
<html>
<head>
    <title>Laporan Stok Gudang</title>
    <style>
        body {
            font-family: 'Helvetica', sans-serif;
            font-size: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #777;
            padding: 6px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: center;
        }
        .header-section {
            text-align: center;
            margin-bottom: 20px;
        }
        .header-section h2 {
            margin: 0;
        }
        .header-section p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="header-section">
        <h2>Laporan Stok Barang Gudang</h2>
        <p>Dicetak pada tanggal: <?php echo e($tanggalCetak); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kategori</th>
                <th>Merek</th>
                <th>Model Barang</th>
                <th>Stock</th>
                <th>Perbaikan</th>
                <th>Rusak</th>
                <th>Stok Akhir</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $stokBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item['kategori']); ?></td>
                    <td><?php echo e($item['merek']); ?></td>
                    <td><?php echo e($item['model']); ?></td>
                    <td style="text-align: center;"><?php echo e($item['jumlah_total']); ?></td>
                    <td style="text-align: center;"><?php echo e($item['jumlah_perbaikan']); ?></td>
                    <td style="text-align: center;"><?php echo e($item['jumlah_rusak']); ?></td>
                    <td style="text-align: center;"><?php echo e($item['jumlah_tersedia']); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" style="text-align: center;">Tidak ada data yang cocok dengan filter yang diterapkan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
         <?php if($stokBarang->isNotEmpty()): ?>
        <tfoot>
            <tr class="total-row">
                <td colspan="4" style="text-align: right;">TOTAL KESELURUHAN</td>
                <td style="text-align: center;"><?php echo e($stokBarang->sum('jumlah_total')); ?></td>
                <td style="text-align: center;"><?php echo e($stokBarang->sum('jumlah_perbaikan')); ?></td>
                <td style="text-align: center;"><?php echo e($stokBarang->sum('jumlah_rusak')); ?></td>
                <td style="text-align: center;"><?php echo e($stokBarang->sum('jumlah_tersedia')); ?></td>
            </tr>
        </tfoot>
        <?php endif; ?>
    </table>
</body>
</html>
<?php /**PATH D:\laragon\www\inventaris-bintang\resources\views\reports\laporan_stok_pdf.blade.php ENDPATH**/ ?>