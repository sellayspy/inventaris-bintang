<?php

namespace App\Models\View;

use Illuminate\Database\Eloquent\Model;

class ViewBarangMasuk extends Model
{
    protected $table = 'view_barang_masuk';
    public $timestamps = false;
}
