<?php

namespace App\Models\View;

use Illuminate\Database\Eloquent\Model;

class ViewBarangKeluar extends Model
{
    protected $table = 'view_barang_keluar';
    public $timestamps = false;
}
