<?php

namespace App\Models\View;

use Illuminate\Database\Eloquent\Model;

class ViewMutasiBarang extends Model
{
    protected $table = 'view_mutasi_barang';
    public $timestamps = false;
}
