<?php

namespace App\Models\View;

use Illuminate\Database\Eloquent\Model;

class ViewBarangKembali extends Model
{
    protected $table = 'view_barang_kembali';
    public $timestamps = false;
}
