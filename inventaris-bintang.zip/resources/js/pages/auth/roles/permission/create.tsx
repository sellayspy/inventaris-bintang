import PermissionForm from './permission-form';

export default function Create() {
    return <PermissionForm />;
}
